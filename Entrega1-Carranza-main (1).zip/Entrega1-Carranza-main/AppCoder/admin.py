from django.contrib import admin
from .models import Futbolista, Basquetbolista, Tenista

# Register your models here.

admin.site.register(Futbolista)
admin.site.register(Basquetbolista)
admin.site.register(Tenista)